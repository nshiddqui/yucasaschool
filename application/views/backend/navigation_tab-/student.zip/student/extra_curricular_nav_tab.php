  <div class="container-fluid">
    <div class="row"> 
      <ul class="list-inline nav nav-tabs ed ajax-navigation" style="padding-left: 0;">
        <li class="<?php if ($activeTab == 'extra_curricular_dashboard'){echo "active";}?>"><a href="#extra_curricular_dashboard" class="" role="tab" data-toggle="tab" aria-expanded="true" >Extra Curricular</a></li>
        <!--li class="<?php if ($activeTab == 'event'){echo "active";}?>"><a href="#event" class=""  role="tab" data-toggle="tab" aria-expanded="true">Event</a></li-->
        <li class="<?php if ($activeTab == 'noticeboard'){echo "active";}?>"><a href="#noticeboard" class=""  role="tab" data-toggle="tab" aria-expanded="true">Noticeboard</a></li>
        <li class="<?php if ($activeTab == 'certification'){echo "active";}?>"><a href="#certification" class=""  role="tab" data-toggle="tab" aria-expanded="true">Certification</a></li>
      </ul>
    </div>
  </div>
  <div class="tab-content">
    <div  class="tab-pane fade <?php if ($activeTab == 'extra_curricular_dashboard'){echo " active in";}?>" id="extra_curricular_dashboard">
      <ul class="list-inline ajax-sub-nav">
        <li><a href="<?php echo base_url(); ?>index.php/student/extra_curricular_dashboard" class="url-link" data-url="<?php echo base_url(); ?>index.php/student/extra_curricular_dashboard"><i class="entypo-chart-area"></i> Dashboard</a></li>
      </ul>
    </div>
    <!--div  class="tab-pane fade <?php if ($activeTab == 'event'){echo " active in";}?>" id="event">
      <ul class="list-inline ajax-sub-nav">
        <li><a href="<?php echo base_url(); ?>index.php/student/event" class="url-link" data-url="<?php echo base_url(); ?>index.php/student/event"><i class="fa fa-list-ol"></i>Event</a></li>
      </ul>
    </div-->
	<div  class="tab-pane fade <?php if ($activeTab == 'noticeboard'){echo " active in";}?>" id="noticeboard">
      <ul class="list-inline ajax-sub-nav">
        <li><a href="<?php echo base_url(); ?>index.php/student/noticeboard" class="url-link" data-url="<?php echo base_url(); ?>index.php/student/noticeboard"><i class="fa fa-list-ol"></i>Noticeboard</a></li>
      </ul>
    </div>
	<div  class="tab-pane fade <?php if ($activeTab == 'certification'){echo " active in";}?>" id="certification">
      <ul class="list-inline ajax-sub-nav">
        <li><a href="<?php echo base_url(); ?>index.php/student/view_all_certificates" class="url-link" data-url="<?php echo base_url(); ?>index.php/student/view_all_certificates"><i class="fa fa-list-ol"></i>View All Certificate</a></li>
        <li><a href="<?php echo base_url(); ?>index.php/student/apply_for_certificates" class="url-link" data-url="<?php echo base_url(); ?>index.php/student/apply_for_certificates"><i class="fa fa-list-ol"></i>Apply For Certificate</a></li>
      </ul>
    </div>
  </div>