
<div class="container-fluid teacher-feedback">



  <div class="row question-response">

    <div class="col-sm-12">
      <div class="responses-details">
      <ul class="list-inline" style="color: #000">
        <li><strong>Feedback Form Name : </strong> Quaterly Name</li>
        <li><strong>Teacher Name</strong> Alok Tiwari</li>
        <li><strong>Feedback Id</strong> ANON2365</li>
      </ul>
    </div>
    </div> 
    <div class="question-box">
      <div class="col-md-12">
        <div class="form-group">
             <p> <strong>Question 1.</strong>The form below contains three inline radio buttons:</p>
              <form>
                <label class="radio-inline">
                  <input type="radio" name="optradio" checked>Option 1
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 2
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 3
                </label>
              </form>
            
      </div>
    </div>
  </div>
  </div>

  <div class="row question-response">
    <div class="question-box">
      <div class="col-md-12">
        <div class="form-group">
             <p> <strong>Question 1.</strong>The form below contains three inline radio buttons:</p>
              <form>
                <label class="radio-inline">
                  <input type="radio" name="optradio" checked>Option 1
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 2
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 3
                </label>
              </form>
            
      </div>
    </div>
  </div>
  </div>

  <div class="row question-response">
    <div class="question-box">
      <div class="col-md-12">
        <div class="form-group">
             <p> <strong>Question 1.</strong>The form below contains three inline radio buttons:</p>
              <form>
                <label class="radio-inline">
                  <input type="radio" name="optradio" checked>Option 1
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 2
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 3
                </label>
              </form>
            
      </div>
    </div>
  </div>
  </div>

  <div class="row question-response">
    <div class="question-box">
      <div class="col-md-12">
        <div class="form-group">
             <p> <strong>Question 1.</strong>The form below contains three inline radio buttons:</p>
              <form>
                <label class="radio-inline">
                  <input type="radio" name="optradio" checked>Option 1
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 2
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 3
                </label>
              </form>
            
      </div>
    </div>
  </div>
  </div>

  <div class="row question-response">
    <div class="question-box">
      <div class="col-md-12">
        <div class="form-group">
             <p> <strong>Question 1.</strong>The form below contains three inline radio buttons:</p>
              <form>
                <label class="radio-inline">
                  <input type="radio" name="optradio" checked>Option 1
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 2
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 3
                </label>
              </form>
            
      </div>
    </div>
  </div>
  </div>

  <div class="row question-response">
    <div class="question-box">
      <div class="col-md-12">
        <div class="form-group">
             <p> <strong>Question 1.</strong>The form below contains three inline radio buttons:</p>
              <form>
                <label class="radio-inline">
                  <input type="radio" name="optradio" checked>Option 1
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 2
                </label>
                <label class="radio-inline">
                  <input type="radio" name="optradio">Option 3
                </label>
              </form>
            
      </div>
    </div>
  </div>
  </div>

  <div class="row question-response">
    <div class="question-box">
      <div class="col-md-12">
        <div class="form-group">
             <p> <strong>Question 1.</strong>The form below contains three inline radio buttons:</p>
             <textarea name="" id="" cols="30" rows="10" style="width: 100%" class="form-control"></textarea>
            
      </div>
    </div>
  </div>
  </div>

</div>



<script>
  $(document).ready(function() {
        setTimeout(() => $('.selectpicker').select2(), 1000);
    });

</script>