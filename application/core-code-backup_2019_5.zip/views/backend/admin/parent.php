<?php $activeTab = "parent_and_gaurdians"; ?>
<style type="text/css">
    .button_design{
      background-color:#e4e4e4;
      border:1px solid #aaa;
      border-radius:4px;
      cursor:default;
      float: left;

      margin-right: 5px;
      margin-top:5px;
      padding:0 5px; 
    }
</style>
<div class="page-header-content container-fluid">
   <div class="page-header">
    <div class="breadcrumb-line">
      <ul class="breadcrumb">
        <li><a href="#"><i class="entypo-home"></i>Home</a></li>
        <li><a href="#">Student</a></li>
        <li class="active">Parent & Gaurdians</li>
        <a href="#" class="pull-right"><i class="entypo-chat"></i> Support</a>
      </ul>
      <a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
    </div>
  </div>
<!-- Including Navigation Tab 
<?php //include base_path().'application/views/backend/navigation_tab/student_nav_tab.php'; ?> -->
<!-- Including Navigation Tab -->
</div>
<a href="javascript:;" onclick="showAjaxModal('<?php echo site_url('modal/popup/modal_parent_add/');?>');"
                class="btn btn-primary pull-right">
                <i class="entypo-plus-circled"></i>
                <?php echo get_phrase('add_new_parent');?>
                </a>
<br>

               <table class="table table-bordered datatable" id="parents-">
                    <thead>
                        <tr>
                            <th><div><?php echo get_phrase('parent_id');?></div></th>
                         
                            <th><div><?php echo get_phrase('name');?></div></th>
                            <th><div><?php echo get_phrase('email');?></div></th>
                            <th><div><?php echo get_phrase('phone');?></div></th>
                            <th><div><?php echo get_phrase('student_name');?></div></th>
                            <th><div><?php echo get_phrase('profession');?></div></th>
                            <th><div><?php echo get_phrase('options');?></div></th>

                        </tr>
                    </thead>
					
					<tbody>
					<?php  foreach($parent_list as $row){?>
					
						<tr>
							<td><?php echo $row['parent_id'] ;?></td>
							
							<td><?php echo $row['name'] ;?></td>
							<td><?php echo $row['email'] ;?></td>
							<td><?php echo $row['phone'] ;?></td>
							<td><ul class="" style="padding:0px;">
						    <?php  $studentlists =  $this->db->get_where('student',array('parent_id'=>$row['parent_id']))->result(); ?>
							 <?php foreach($studentlists as $student_values){
                                   echo  '<li class="button_design" title="Nursery" style="list-style: none;"><a href="student_profile/'.$student_values->student_id.'">'. @$this->crud_model->get_type_name_by_id('student',$student_values->student_id).'</a></li>
                                   ';
                                } 
							 ?>
                                  
                             </ul></td>
							<td><?php echo $row['profession'] ;?></td>
							<td>
							<div class="btn-group">
							<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button>
							<ul class="dropdown-menu dropdown-default pull-right" role="menu">
							<li><a href="#" onclick="parent_edit_modal(<?php echo $row['parent_id'] ;?>)"><i class="entypo-pencil"></i><?php echo get_phrase('edit');?></a></li>
							<li class="divider"></li>
							<li><a href="#" onclick="parent_delete_confirm(<?php echo $row['parent_id'] ;?>)"><i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li>
							</ul>
							</div>
							</td>
						</tr>
						
						<?php } ?>
					</tbody>
                </table>
</div>


<!-----  DATA TABLE EXPORT CONFIGURATIONS ---->
<script type="text/javascript">

    jQuery(document).ready(function($) {
        $.fn.dataTable.ext.errMode = 'throw';
        $('#parents').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax":{
                "url": "<?php echo site_url('admin/get_parents') ?>",
                "dataType": "json",
                "type": "POST",
            },
            "columns": [
                { "data": "parent_id" },
                { "data": "name" },
                { "data": "email" },
                { "data": "phone" },
                { "data": "profession" },
                { "data": "options" },
            ],
            "columnDefs": [
                {
                    "targets": [5],
                    "orderable": false
                },
            ],
			dom: 'Bfrtip',
              iDisplayLength: 10,
              buttons: [
              {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: ':not(:last-child)',
                }
 },
      {
                extend: 'csvHtml5',
                exportOptions: {
                    columns: ':not(:last-child)',
                }
 },
  
              ],
        
              search: true
        });
    });

    function parent_edit_modal(parent_id) {
        showAjaxModal('<?php echo site_url('modal/popup/modal_parent_edit/');?>' + parent_id);
    }

    function parent_delete_confirm(parent_id) {
        confirm_modal('<?php echo site_url('admin/parent/delete/');?>' + parent_id);
    }

</script>
