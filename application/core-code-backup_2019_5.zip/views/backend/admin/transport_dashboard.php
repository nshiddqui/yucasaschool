<style>
       
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }

      .route-container{
        /*z-index: 99999;*/
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #description {
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
      }

      #infowindow-content .title {
        font-weight: bold;
      }

      #infowindow-content {
        display: none;
      }

      #map #infowindow-content {
        display: inline;
      }

      #map{
        height:58vh;
        width: 100%;
      }


        #section_holder {
          position: relative;
          z-index: 55;
        }

      .pac-card {
        margin: 10px 10px 0 0;
        border-radius: 2px 0 0 2px;
        box-sizing: border-box;
        -moz-box-sizing: border-box;
        outline: none;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        background-color: #fff;
        font-family: Roboto;
      }

      #pac-container {
        padding-bottom: 12px;
        margin-right: 12px;
      }

      .pac-controls {
        display: inline-block;
        padding: 5px 11px;
      }

      .pac-controls label {
        font-family: Roboto;
        font-size: 13px;
        font-weight: 300;
      }

      #pac-input {
        background-color: #fff;
        font-family: Roboto;
        font-size: 15px;
        font-weight: 300;
        margin-left: 12px;
        padding: 0 11px 0 13px;
        text-overflow: ellipsis;
        width: 400px;
      }

      #pac-input:focus {
        border-color: #4d90fe;
      }

      .map-close {
      background: #333;
      width: 20%;
      margin: 2% 0;
      text-align: center;
    }

      #target {
        width: 345px;
      }

      .route-container {
          position: relative;
          width: 100%;
          background: #fff;
          padding: 1%;
          border: 0px solid #eee;
          box-shadow:none;
          /*display: none;*/
        }

        body .widget-indicators{
          margin-top: 15px;
        }
    </style>

<?php $activeTab = "transport_dashboard"; ?>
<div class="page-header-content container-fluid">
   <div class="page-header">
    <div class="breadcrumb-line">
      <ul class="breadcrumb">
        <li><a href="#"><i class="entypo-home"></i>Home</a></li>
        <li class="active">Transport Dashboard</li>
        <a href="#" class="pull-right"><i class="entypo-chat"></i> Support</a>
      </ul>
      <a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>
    </div>
  </div>
<!-- Including Navigation Tab -->
<?php include base_path().'application/views/backend/navigation_tab/transport_nav_tab.php'; ?> 
<!-- Including Navigation Tab -->
</div>

<?php 


?>

<div class="container-fluid">
<!-- WIDGET SECTION STARTS HERE -->
  <div class="row">
      <div class="">
        <?php 
       $total_active =  $this->db->get_where('routes',array('status'=>1))->result();
       $total_member =  $this->db->get_where('student',array('transport_id'=>1))->result();
       $member_avg   =  "";
       if(count($total_member) != ""){
         $member_avg = count($total_member)/count($total_active);
         $member_avg =round($member_avg ,2);
       }
       $total_route_stops = array();
       foreach ($total_active as $key => $stops) {
        $route_stops =  $this->db->get_where('route_stops',array('route_id'=>$stops->id))->result();
        $total_route_stops[] = count($route_stops);
      }   
      
     
       
     ?>


      <div class="widget-indicators">
        <div class="indicator-item">

          <div class="indicator-item-icon">
            <div class="icon"><img src="<?php echo base_url();?>assets/images/list.png" style="max-height:40px;"></div>
          </div>

         <div class="indicator-item-value"><span class="indicator-value-counter" data-toggle="counter" data-end="1646"><?php echo count($total_active);?></span>
            
          </div>
          <div class="indicator-value-title">Total NO. of routes</div>
        </div>


        <div class="indicator-item">
          <div class="indicator-item-icon">
            <div class="icon"><img src="<?php echo base_url();?>assets/images/stopwatch.png" style="max-height:40px;"></div>
          </div>
           <div class="indicator-item-value"><span class="indicator-value-counter" data-toggle="counter" data-end="857"><?php   echo max($total_route_stops);  ?></span>
            
          </div>
          <div class="indicator-value-title">Highest route capacity  :  </div>
        </div>



        <div class="indicator-item">
          <div class="indicator-item-icon">
            <div class="icon"><img src="<?php echo base_url();?>assets/images/essay.png" style="max-height:40px;"></div>
          </div>
          <div class="indicator-item-value"><span class="indicator-value-counter" data-toggle="counter" data-decimals="1" data-end="17"><?php echo $member_avg;?></span>
           
          </div>
           <div class="indicator-value-title">AVG. No of members per route </div>
        </div>


        
        <div class="indicator-item">
          <div class="indicator-item-icon">
             <div class="icon"><img src="<?php echo base_url();?>assets/images/checklist.png" style="max-height:40px;"></div>
          </div>
          <div class="indicator-item-value"><span class="indicator-value-counter" data-toggle="counter" data-decimals="2" data-end="540" data-prefix="$"><?php echo count($total_active);?></span>
            
          </div>
          <div class="indicator-value-title">Currently Active Routes</div>

        </div>



      </div>
    </div>
  </div>
  
  <!-- WIDGET SECTION ENDS HERE -->

    <!-- CHART SECTION BEGINS HERE -->
    <div class="row">
    <div class="col-sm-12 p0">
      <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?> " id="hostel-info" >
        <div class="panel-group ">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-expanded="true" aria-expanded="true" href="#hostel_info_chart" >Transport Route<span class="open-close pull-right in"><i class="fas fa-chevron-down"></i></span></a> </h4>
            </div>
            <div id="hostel_info_chart" class="panel-collapse collapse in" data-expanded="true">
              <div id="section_holder">
                <div class="col-md-6">

                    <div class="form-group">
                        <label class="control-label" style="margin-bottom: 5px;"><?php echo get_phrase('route_list'); ?></label>
                        <select name="route_id" id="route_id" class="form-control" onchange="getliveroute(this)">
                            <?php 

                            $total_routes = count($routelist);
                             
                              foreach($routelist as $route){          
                                  $routedetails =  @$this->db->get_where('routes',array('id'=>$route->id))->row();
                                                                      
                                   if( $routedetails != ""){ 
                                                                              

                                      $md = json_decode($routedetails -> stop_details);
                                      $ms = array();

                                      //print_r($md); 
                                      for($i = 0; $i < sizeof($md) - 1; $i++) {
                                          $ms[$i] = json_decode($md[$i]); 
                                          $ms[$i] -> lat = $ms[$i] -> lat .'';
                                          $ms[$i] -> lng = $ms[$i] -> lng .'';
                                          $ms[$i] -> distance = $ms[$i] -> distance .'';
                                      }

                                       $arr = array();
                                       $arr2=array();
                                       $k=1;
                                      
                                      $arr2[$k] = $routedetails->source_lat.','.$routedetails->source_long;
                                       foreach ($ms as $key => $dt) {
                                          $k++;
                                          $arr[] = $dt->lat.'%2C'.$dt->lng;
                                          if($k<=count($ms)+1){
                                          $arr2[$k] = $dt->lat.','.$dt->lng;
                                      }
                                       }
                                        $waypointss = implode('%7C',$arr);
                                        $arr2[$k+1] = $routedetails->dest_lat.','.$routedetails->dest_long;

                                    // echo "<br>";
                                      $origin  = $routedetails->source_lat.'%2C'.$routedetails->source_long.'&destination='.$routedetails->dest_lat.'%2C'.$routedetails->dest_long.'&waypoints='.$waypointss;
                                      ?>
                                      <?php
                                      $url = "https://maps.googleapis.com/maps/api/directions/json?origin=".$origin."&key=AIzaSyA3wtFPAIvJyfy5Q1JaW_fP3fuRTX3frD4";
                                      $ch = curl_init();
                                      curl_setopt ($ch, CURLOPT_URL, $url);
                                      curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 5);
                                      curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
                                      $contents = curl_exec($ch);
                                      if (curl_errno($ch)) {
                                        echo curl_error($ch);
                                        echo "\n<br />";
                                        $contents = '';
                                      } else {
                                        curl_close($ch);
                                      }

                                      if (!is_string($contents) || !strlen($contents)) {
                                      echo "Failed to get contents.";
                                      $contents = '';
                                      }

                                      //echo $contents;


                                     // $jsonData = json_decode(file_get_contents('https://maps.googleapis.com/maps/api/directions/json?origin='.$origin.'&key=AIzaSyA3wtFPAIvJyfy5Q1JaW_fP3fuRTX3frD4'));
                                      $jsonData = json_decode($contents);

                                      $var=$jsonData->routes[0]->overview_polyline->points;
                                      $err=json_decode(json_encode($arr2,false));   
                                      }                                      


                                ?>
                                <option value="<?php echo $route->vehicle_ids; ?>" data-driver ="<?php echo $route->driver;?>"  data-id='<?php echo json_encode($err);?>' data-name="<?php echo $var;?>"><?php echo $route->title;?> </option>
                                <?php
                              }
                            ?>
                        </select>
                    </div>

                </div>
            </div>

            <div class="route-container">
               <div id="map"></div>

               <div class="close">
                 close
               </div>
            </div>
           </div>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!-- CHART SECTION BEGINS HERE -->


</div>


 <script>
    // This example creates an interactive map which constructs a polyline based on
    // user clicks. Note that the polyline only appears once its path property
    // contains two LatLng coordinates.
    var poly;
    var map;
    var markers_val_ =  [ ];
    var markers_arr = [];
    function initMap() {
        
        
   // Create a new StyledMapType object, passing it an array of styles,
        // and the name to be displayed on the map type control.
        var styledMapType = new google.maps.StyledMapType(
           [
  {
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#ddf7f4"
      }
    ]
  },
  {
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#4294f9"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#5cb4de"
      }
    ]
  }
]
,
            {name: 'Styled Map'});
        
        
        map = new google.maps.Map(document.getElementById('map'), {
          zoom: 10,
            mapTypeControlOptions: {
            mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain',
                    'styled_map']
          },
          center: {lat: 28.668502452598734, lng: 77.2193798407227}  // Center the map on Chicago, USA.
        });
        //28.668502452598734, 77.2193798407227
       
        // Add a listener for the click event
       // map.addListener('click', addLatLng);
        map.mapTypes.set('styled_map', styledMapType);
        map.setMapTypeId('styled_map');
     }


      var vari = 0;
      // Handles click events on a map, and adds a new point to the Polyline.
      function addLatLng(event,markers_arr) {

            // poly.setMap(null);
            //  path = poly.getPath();
            //  for (var i = 0; i < markers_val_.length; i++) {
            //     markers_val_[i].setMap(null);
            //  }
          

            //  markers_val_ = [];
          console.log("Value of i is" + vari);
          
          vari++;
          //console.log("Event VAlue is" + event);
          //console.log("Markers Array Value is " + markers_arr);
          
          console.log('Markers array lenth is: ' + markers_arr.length);

           if(event == "" && markers_arr.length == 0){
            //alert('value');
            poly = new google.maps.Polyline({
              strokeColor: '#fff',
              strokeOpacity: 1.0,
              strokeWeight: 0
            });  
             poly.setMap(null);
             path = poly.getPath();
             for (var i = 0; i < markers_val_.length; i++) {
                markers_val_[i].setMap(null);
             }
             markers_val_ = [];
           }else if(event != ""){
            poly = new google.maps.Polyline({
              strokeColor: '#000',
              strokeOpacity: 1.0,
              strokeWeight: 3
            });  
            poly.setMap(map);
            path = poly.getPath();
            var decodedPath = event;
            decode(decodedPath,markers_arr);
         } 
       }


    function decode(encoded,markers_arr){
         //path.push({latitude:( lat / 1E5),longitude:( lng / 1E5)});
         //console.log(encoded);
         if(markers_arr != "")
          var routeect_markers = JSON.parse(markers_arr);
          var array = $.map(routeect_markers, function(value, index) {
            return [value];
         });

          var pointss=[];
          var i=0;
          var t ="";
       for(i=0;i<array.length;i++){
        var t=array[i].split(',');
       // console.log(i +'=='+ array.length);
        if(i == 0)
          icon   = new google.maps.MarkerImage('https://mts.googleapis.com/vt/icon/name=icons/spotlight/spotlight-waypoint-a.png&text=A&psize=16&font=fonts/Roboto-Regular.ttf&color=ff333333&ax=44&ay=48&scale=1');
        else if(i == (array.length)-1)
          icon   = new google.maps.MarkerImage('https://mts.googleapis.com/vt/icon/name=icons/spotlight/spotlight-waypoint-a.png&text=B&psize=16&font=fonts/Roboto-Regular.ttf&color=ff333333&ax=44&ay=48&scale=1');
        else
          icon = "";

          marker = new google.maps.Marker({
          position: new google.maps.LatLng(parseFloat(t[0]), parseFloat(t[1])),
          title: '#' + path.getLength(),
          icon :icon,
          map: map
         });
         markers_val_.push(marker);
   }
    // array that holds the points
    // alert(encoded);
    var points=[ ]
    var index = 0, len = encoded.length;
    var lat = 0, lng = 0;
    while (index < len) {
        var b, shift = 0, result = 0;
        do {
            b = encoded.charAt(index++).charCodeAt(0) - 63;
              result |= (b & 0x1f) << shift;
              shift += 5;
           } while (b >= 0x20);


       var dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
       lat += dlat;
       shift  = 0;
       result = 0;
       do {
         b = encoded.charAt(index++).charCodeAt(0) - 63;
         result |= (b & 0x1f) << shift;
         shift += 5;
         } while (b >= 0x20);
       var dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
       lng += dlng;

       path.push(new google.maps.LatLng(lat / 1E5, lng / 1E5));         /////create polyline and route
       points.push({latitude:( lat / 1E5),longitude:( lng / 1E5)})  ;
    }
  }
 </script>

 <script>
    driver_id = "";  var counter = 0;markersvalue="";
    function getliveroute(ths){


    var currentOption = $('#route_id>option:selected');
    var mar= currentOption.attr("data-id");
    var mari=currentOption.attr("data-name");
    //console.log(markers_val_);
    markers_val_ = [];
    
    
     addLatLng("","");
 
     addLatLng(mari,mar);
   

   
    var driver_id = currentOption.attr("data-driver");
    $(ths).addClass("active_driver");
    // getlivepoints();
    $('.route-container').css('display', 'block');
    
 }

    $(".close").click(function(){  
     // $('.route-container').css('display', 'none');
     addLatLng("","");
    });

    // function getlivepoints(){
    //     jsonval = "";
    //     driver_id = $(".active_driver").attr("data-driver");
    //     $.ajax({       
    //         type   : "POST",
    //         url    : "<?php echo site_url('transport/vehicle/getLocationOfDriver'); ?>",
    //         data   : {driver_id:driver_id},               
    //         async  : false,
    //         success: function(response){                                                   
    //            if(response != 0)
    //             { 
    //               //alert(interval);
    //               console.log(markersvalue);
    //               var jsonval = JSON.parse(response);
    //               counter = counter+interval;
    //               if(counter > 6000){
    //                  markersvalue.setMap(null);
    //                  if(markersvalue != "")
    //                     markersvalue.setMap(null);
                        
    //                     interval = 0;

    //                    markersvalue = new google.maps.Marker({
    //                    position: new google.maps.LatLng(parseFloat(jsonval.latitude), parseFloat(jsonval.longitude)),
    //                    title: '#' + path.getLength(),
    //                    icon: {
    //                        url: "<?php echo base_url('assets/images/bus.png');?>",scaledSize: new google.maps.Size(60, 60)
    //                    } ,
    //                    map: map
    //                   });  

    //               }else{
    //                    markersvalue = new google.maps.Marker({
    //                    position: new google.maps.LatLng(parseFloat(jsonval.latitude), parseFloat(jsonval.longitude)),
    //                    title: '#' + path.getLength(),
    //                    icon: {
    //                        url: "<?php echo base_url('assets/images/bus.png');?>",scaledSize: new google.maps.Size(60, 60)
    //                    } ,
    //                    map: map
    //                   });
    //               }
    //           }
    //         }
    //     });
    // }
  interval = 1000 * 6; // where X is your every X minutes
  // window.setInterval(getlivepoints, interval);

               

</script>
<!-- https://maps.googleapis.com/maps/api/directions/json?origin=28.667899981213115%2C77.22796290957035&destination=28.646208704837782%2C77.11638301455082&waypoints=28.658862494805%2C77.203243671289%7C28.651933227536%2C77.178867755762%7C28.655247282061%2C77.152088580957%7C28.65072809083%2C77.124279437891&key=AIzaSyA3wtFPAIvJyfy5Q1JaW_fP3fuRTX3frD4 -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA3wtFPAIvJyfy5Q1JaW_fP3fuRTX3frD4&libraries=places&callback=initAutocomplete"
       async defer></script> -->
 <script async defer 
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA3wtFPAIvJyfy5Q1JaW_fP3fuRTX3frD4&callback=initMap">
</script>
