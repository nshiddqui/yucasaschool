<?php
  $login_user_id = $this->session->userdata('login_user_id'); 
  $login_role_id = $this->session->userdata('role_id'); 

  //$notification_data = $this->db->query("select * from notification_alert where status = 1 AND send_to_role = $login_role_id AND (send_to = $login_user_id OR send_to IS NULL)")->result();
$notification_data = $this->db->query("SELECT * FROM `notification_alert` where status = 1 
 ORDER BY `id` DESC ")->result();
  $count_notification = count($notification_data);

?>

<div class="">
	<!-- Raw Links -->
	<div class="col-md-12 col-sm-12 clearfix top_header_bar">
        <ul class="list-inline links-list pull-left">
        <!-- Language Selector -->
        	<a href="<?php echo base_url();?>/index.php/login">
                <img src="<?php echo base_url();?>uploads/logo.png" style="max-height:40px;">
            </a> 
        </ul>
	

		<?php include('event-ticker.php');?>

        <ul class="list-inline links-list pull-right right-info-bar">
			<li id="session_static">
	           	<h4>
       			<a href="#" style="color: #696969;"
       				<?php if($account_type == 'admin'):?>
       				onclick="get_session_changer()"
       			    <?php endif;?>>
       				<?php echo get_phrase('running_session');?> : <?php echo $running_year.' ';?><i class="entypo-down-dir"></i>
       			</a>
           		</h4>
       		</li>
		<li class="dropdown language-selector">
			 <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-close-others="true">
                <i class="entypo-user"></i>
					<?php
					if($account_type == 'designation_users'){
						$name = $this->db->get_where('employees', array('user_id' => $login_user_id))->row()->name;
						echo $name;
					}else{
					   //$name = $this->db->get_where($account_type, array($account_type.'_id' => $login_user_id))->row()->name;
						//echo $name;
					}
					?>
        <?php   $_rolesdata=$this->session->userdata('role_id')?>
            <?php
                $roless = $this->db->get_where('roles' , array(
                    'id' => $_rolesdata
                ))->result_array();
             foreach ($roless as $row):
			 $role_name=$row['name'];
			 endforeach
            ?>
		<span style="margin-left: 5px;padding-left: 5px;border-left: 1px solid #eee;"><?php echo $role_name;?></span>
    </a>

			<?php if ($account_type != 'parent'):?>
				<ul class="dropdown-menu <?php if ($text_align == 'right-to-left') echo 'pull-right'; else echo 'pull-left';?>">
					<li>
						<a href="<?php echo site_url($account_type . '/manage_profile');?>">
                        	<i class="entypo-info"></i>
							<span><?php echo get_phrase('edit_profile');?></span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url($account_type . '/manage_profile');?>">
                        	<i class="entypo-key"></i>
							<span><?php echo get_phrase('change_password');?></span>
						</a>
					</li>

					<li>
						<a href="<?php echo site_url('login/logout');?>">
							<i class="entypo-logout right"></i> <?php echo get_phrase('log_out'); ?>
						</a>
					</li>
				</ul>
			<?php endif;?>
			<?php if ($account_type == 'parent'):?>
				<ul class="dropdown-menu <?php if ($text_align == 'right-to-left') echo 'pull-right'; else echo 'pull-left';?>">
					<li>
						<a href="<?php echo site_url('parents/manage_profile');?>">
                        	<i class="entypo-info"></i>
							<span><?php echo get_phrase('edit_profile');?></span>
						</a>
					</li>
					<li>
						<a href="<?php echo site_url('parents/manage_profile');?>">
                        	<i class="entypo-key"></i>
							<span><?php echo get_phrase('change_password');?></span>
						</a>
					</li>

					<li>
						<a href="<?php echo site_url('login/logout');?>">
							<?php echo get_phrase('log_out'); ?><i class="entypo-logout right"></i>
						</a>
					</li>

				</ul>
				<?php endif;?>
			</li>
			<!-- <li>
				<a class="bell <?php if($count_notification > 0){ echo 'active';} ?>" target="_blank" >
					<span class="badge"><i class="fa fa-bell"></i></span>
				</a>
			</li> -->

			<li>
			<ul class="nav navbar-nav navbar-right">
        <li class="dropdown notification-drop">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="badge bell-badge"><i class="fa fa-bell"></i></span><span class="number-new"><?php echo $count_notification;?></span></a>
          <ul class="dropdown-menu notify-drop">
            <div class="notify-drop-title">
            	<div class="row">
            		<div class="col-sm-12 text-center">Notifications <span class=""><?php echo $count_notification;?></span></div>
            	</div>
            </div>
            <!-- end notify title -->
            <!-- notify content -->
            <div class="drop-content">

              <?php
             
               foreach ($notification_data as $key => $dt_notification) {
                $name_notification="";
                if($dt_notification->create_by_role == PARENTT){
                    $name_notification =  @$this->db->get_where('parent',array('parent_id'=>$dt_notification->create_user_id))->row()->name;
                }else if($dt_notification->create_by_role == TEACHER){
                    $name_notification =  @$this->db->get_where('teacher',array('teacher_id'=>$dt_notification->create_user_id))->row()->name;
                }else if($dt_notification->create_by_role == 1){
                    $name_notification =  @$this->db->get_where('admin',array('admin_id'=>$dt_notification->create_user_id))->row()->name;
                }
             

              ?>
                <a href="<?php echo site_url($this->session->userdata('login_type').'/notification');?>">
                <li>
            		<div class="col-md-3 col-sm-3 col-xs-3"><div class="notify-img"><img src="https://placehold.it/45x45" alt=""></div></div>
            		<div class="col-md-9 col-sm-9 col-xs-9 pd-l0"><h4 class="title"><?php echo  $dt_notification->title;?> <span class="pull-right student">( <?php echo $name_notification;?> )</span> </h4>
            		<p class="summary"><?php echo substr($dt_notification->msg, 0, 15);?>..<span class="label label-default pull-right">New</span></p>
            		<p class="time "><?php echo  $dt_notification->timestamp;?></p>
            		</div>
				   </li>
            </a>

            <?php } ?>
			
            </div>
            <div class="notify-drop-footer text-center">
            	<a href="<?php echo site_url($this->session->userdata('login_type').'/notification');?>"> View All</a>
            </div>
          </ul>
			</li>
		</ul>
	</div>

</div>
<!-- <hr style="margin-top:0px;" /> -->

<script type="text/javascript">
	function get_session_changer()
	{
		$.ajax({
            url: '<?php echo site_url('admin/get_session_changer');?>',
            success: function(response)
            {
                jQuery('#session_static').html(response);
            }
        });
	}
</script>


