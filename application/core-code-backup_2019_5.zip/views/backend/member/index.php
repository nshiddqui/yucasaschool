<?php $activeTab = "memebers"; ?>
<div class="page-header-content container-fluid">
  <div class="page-header">
    <div class="breadcrumb-line">
      <ul class="breadcrumb">
        <li><a href="#"><i class="entypo-home"></i>Home</a></li>
        <li class="active">Hostel Memebers</li>
        <a href="#" class="pull-right"><i class="entypo-chat"></i> Support</a>
      </ul>
      <a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a><a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a> </div>
  </div>
 <?php include base_path().'application/views/backend/navigation_tab/hostel_nav_tab.php'; ?> 

</div>


<div class="container-fluid hidden">
  <div class="row">
    <div class="" data-example-id="togglable-tabs">
      <ul  class="nav nav-tabs bordered">
        <li class="<?php if(isset($list)){ echo 'active'; }?>"><a href="<?php echo site_url('member/index/'); ?>"   aria-expanded="true"><i class="fa fa-list-ol"></i> <?php echo $this->lang->line('member'); ?> <?php echo $this->lang->line('list'); ?></a> </li>
        <?php if(has_permission(ADD, 'hostel', 'member')){ ?>
        <li  class="<?php if(isset($add)){ echo 'active'; }?>"><a href="<?php echo site_url('member/add/'); ?>"  aria-expanded="false"><i class="fa fa-plus-square-o"></i> <?php echo $this->lang->line('non_member'); ?> <?php echo $this->lang->line('list'); ?></a> </li>
        <?php } ?>
      </ul>
    </div>
  </div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="tab-content">
      <div  class="tab-pane fade in <?php if(isset($list)){ echo 'active'; }?>" id="tab_member_list" >
        <div class="x_content">
          <table id="datatable-keytable" class="datatable-responsive table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th><?php echo $this->lang->line('sl_no'); ?></th>
                <th><?php echo $this->lang->line('photo'); ?></th>
                <th><?php echo $this->lang->line('name'); ?></th>
                <th><?php echo $this->lang->line('class'); ?></th>
                <th><?php echo $this->lang->line('section'); ?></th>
                <th><?php echo $this->lang->line('roll_no'); ?></th>
                <th><?php echo $this->lang->line('hostel'); ?> <?php echo $this->lang->line('name'); ?></th>
                <th><?php echo $this->lang->line('room_no'); ?></th>
                <th><?php echo $this->lang->line('cost_per_seat'); ?></th>
                <th><?php echo $this->lang->line('action'); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php $count = 1; if(isset($members) && !empty($members)){ ?>
              <?php foreach($members as $obj){ ?>
              <tr>
                <td><?php echo $count++; ?></td>
                <td><img src="<?php echo $this->crud_model->get_image_url('student',$obj->student_id);?>" class="img-circle" width="30" /></td>
                <td><?php echo $obj->name; ?></td>
                <td><?php echo $obj->class_name; ?></td>
                <td><?php echo $obj->section; ?></td>
                <td><?php echo $obj->student_code; ?></td>
                <td><?php echo $obj->hostel_name; ?></td>
                <td><?php echo $obj->room_no; ?> [<?php echo $this->lang->line($obj->room_type); ?>]</td>
                <td><?php //echo $this->gsms_setting->currency_symbol; ?>
                  <?php echo $obj->cost; ?></td>
                <td><?php if(has_permission(DELETE, 'hostel', 'member')){ ?>
                  <a href="<?php echo site_url('member/delete/'.$obj->hm_id); ?>" onclick="javascript: return confirm('<?php echo $this->lang->line('confirm_alert'); ?>');" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> <?php echo $this->lang->line('delete'); ?> </a>
                  <?php } ?></td>
              </tr>
              <?php } ?>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
	  
      <div  class="tab-pane fade in <?php if(isset($add)){ echo 'active'; }?>" id="tab_non_member_list" >
        <div class="x_content">
          <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th><?php echo $this->lang->line('sl_no'); ?></th>
                <th><?php echo $this->lang->line('photo'); ?></th>
                <th><?php echo $this->lang->line('name'); ?></th>
                <th><?php echo $this->lang->line('class'); ?></th>
                <th><?php echo $this->lang->line('section'); ?></th>
                <th><?php echo $this->lang->line('roll_no'); ?></th>
                <th><?php echo $this->lang->line('select'); ?> <?php echo $this->lang->line('hostel'); ?> / <?php echo $this->lang->line('room_no'); ?> </th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $count = 1; if(isset($non_members) && !empty($non_members)){ ?>
              <?php foreach($non_members as $obj){ ?>
              <tr>
                <td><?php echo $count++; ?></td>
                <td><img src="<?php echo $this->crud_model->get_image_url('student',$obj->student_id);?>" class="img-circle" width="30" /></td>
                <td><?php echo $obj->name; ?></td>
                <td><?php echo $obj->class_name; ?></td>
                <td><?php echo $obj->section; ?></td>
                <td><?php echo $obj->student_code; ?></td>
                <td><select  class="form-control col-md-7 col-xs-12 alignleft" name="hostel_id" id="hostel_id_<?php echo $obj->student_id; ?>" onchange="get_room_by_hostel(this.value, '<?php echo $obj->student_id; ?>');" required>
                    <option value="">--<?php echo $this->lang->line('select'); ?> <?php echo $this->lang->line('hostel'); ?>--</option>
                    <?php  
$hostels = $this->db->get_where('hostels',array('status'=>1))->result();                                     
foreach($hostels as $hostel){ ?>
                    <option value="<?php echo $hostel->id; ?>"><?php echo $hostel->name; ?> [<?php echo $this->lang->line($hostel->type); ?>]</option>
                    <?php } ?>
                  </select>
                  <select  class="form-control col-md-7 col-xs-12" name="room_id" id="room_id_<?php echo $obj->student_id; ?>" required>
                    <option value="">--<?php echo $this->lang->line('select'); ?> <?php echo $this->lang->line('room_no'); ?>--</option>
                  </select></td>
                <td><?php if(has_permission(ADD, 'hostel', 'member')){ ?>
                  <a href="javascript:void(0);" id="<?php echo $obj->student_id; ?>" class="btn btn-success btn-xs fn_add_to_hostel"><i class="fa fa-reply"></i> <?php echo $this->lang->line('add'); ?> <?php echo $this->lang->line('hostel'); ?> </a>
                  <?php } ?></td>
              </tr>
              <?php } ?>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
	  
	  
    </div>
  </div>
</div>
<script type="text/javascript">

$(document).ready(function(){
$('.fn_add_to_hostel').click(function(){
var obj      = $(this);  
var user_id  = $(this).attr('id');         
var hostel_id= $('#hostel_id_'+user_id).val();         
var room_id  = $('#room_id_'+user_id).val();

if(hostel_id == ''){
toastr.error('<?php echo $this->lang->line('select'); ?> <?php echo $this->lang->line('hostel'); ?>'); 
return false;
}
if(room_id == ''){
toastr.error('<?php echo $this->lang->line('select'); ?> <?php echo $this->lang->line('room_no'); ?>'); 
return false;
}

$.ajax({       
type   : "POST",
url    : "<?php echo site_url('member/add_to_hostel'); ?>",
data   : { user_id : user_id, hostel_id : hostel_id, room_id : room_id},               
async  : false,
success: function(response){ 
if(response){
toastr.success('<?php echo get_phrase('data_update_success'); ?>');
obj.parents('tr').remove();
}else{
toastr.error('<?php echo get_phrase('update_failed'); ?>'); 
}
}
}); 

});       
});


function get_room_by_hostel(hostel_id, user_id){       

$.ajax({       
type   : "POST",
url    : "<?php echo site_url('ajax/get_room_by_hostel'); ?>",
data   : { hostel_id : hostel_id },               
async  : false,
success: function(response){                                                   
if(response)
{                  
$('#room_id_'+user_id).html(response);
}
}
});         
} 
</script> 
<script type="text/javascript">
$(document).ready(function() {
$('#datatable-responsive, .datatable-responsive').DataTable( {
dom: 'Bfrtip',
iDisplayLength: 15,
buttons: [
'copyHtml5',
'excelHtml5',
'csvHtml5',
'pdfHtml5',
'pageLength'
],
search: true
});
});
</script>