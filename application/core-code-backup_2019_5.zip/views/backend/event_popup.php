<div class="event_popup">
<div class="close-event">
    <i class="fas fa-times"></i>
</div>
    <div class="event_image_slider">
        <div class="slide"><img src="#" alt=""></div>
        <div class="slide"><img src="#" alt=""></div>
        <div class="slide"><img src="#" alt=""></div>
    </div>

    <div class="event-details row">

   
    <div class="item form-group col-sm-12 event-name">
        <label class="control-label col-sm-12" for="title">Jaswant's Rock Concert
        </label>
    
    </div>

    <div class="item form-group col-sm-6">
        <label class="control-label col-md-6" for="title">Event For :
        </label>
        <div class="col-sm-6">
           <div class="event_for">Teachers, Student</div>
        </div>
    </div>

    <div class="item form-group col-sm-6">
        <label class="control-label col-md-6" for="title">Event Place :
        </label>
        <div class="col-sm-6 ">
           <div class="event_place">DPS, Delhi</div>
        </div>
    </div>

    <div class="item form-group col-sm-6">
        <label class="control-label col-md-6" for="title">From Date :
        </label>
        <div class="col-sm-6">
           <div class="from_date">Jaswant's Rock Concert</div>
        </div>
    </div>

    <div class="item form-group col-sm-6">
        <label class="control-label col-md-6" for="title">To Date :
        </label>
        <div class="col-sm-6">
           <div class="to_date">Jaswant's Rock Concert</div>
        </div>
    </div>


    <div class="item form-group col-sm-6">
        <label class="control-label col-md-6" for="title">Note :
        </label>
        <div class="col-sm-6">
           <div class="event_note">Jaswant's Rock Concert</div>
        </div>
    </div>
    </div>
</div>

<div class="overlay-event"></div>