<!-- plugins:css -->
<link rel="stylesheet" href="<?php echo base_url();?>/assets/vendors/iconfonts/mdi/css/materialdesignicons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>/assets/vendors/css/vendor.bundle.base.css">
<link rel="stylesheet" href="<?php echo base_url();?>/assets/vendors/css/vendor.bundle.addons.css">
<!-- endinject -->
<!-- plugin css for this page -->
<!-- End plugin css for this page -->
<!-- inject:css -->
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/style.css">
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/toastr.min.css">
<!-- inject:css -->
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/custom_style.css">
<link rel="shortcut icon" href="<?php echo base_url();?>/assets/images/favicon.png" />
<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" />

<script src="https://cdn.ckeditor.com/ckeditor5/11.2.0/classic/ckeditor.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

