<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin text-right">
            <a href="<?php echo base_url();?>home/add_school" class="btn btn-success btn-fw">
                <i class="mdi mdi-plus"></i>Add School
            </a>
        </div>
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
            <div class="card-body">
               
                <div class="table-responsive">
                <table class="table table-hover table-striped datatable">
                    <thead>
                    <tr>
                       
                        <th>School Name</th>
                        <th>URL</th>
                       
                        <th>Number</th>
                        <th>Email</th>
                        <th>Package</th>
                         <th>Package Install Status</th>
                          <th>DB Install Status</th>
                        <th>Option</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        
                        <td>Kendriya Vidyalaya</td>
                        <td><a href="https://www.demodomain.edurama.in/" target="_blank">Click Here</a></td>
                       
                        <td>9874563210</td>
                        <td>bhuvan@gmail.com</td>
                        <td class="pack-intermediate">Intermediate</td>
                        <td class="pack-intermediate">Intermediate</td>
                        <td class="pack-intermediate">Intermediate</td>
                        <td class="blog__options">
                            <a class="post_edit" href="<?php echo base_url();?>edit-school">
                                <i class="mdi mdi-pencil"></i>
                            </a>
                            <a class="post_delete" href="">
                                <i class="mdi mdi-delete"></i>
                            </a>
                        </td>
                    </tr>
                  
                    
                  
                    </tbody>
                </table>
                </div>
            </div>
            </div>
        </div>

    </div>
</div>